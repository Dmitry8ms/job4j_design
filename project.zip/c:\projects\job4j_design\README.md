# job4j_design
[![Build Status](https://travis-ci.com/Dmitry8ms/job4j_design.svg?branch=master)](https://travis-ci.com/Dmitry8ms/job4j_design)
[![codecov](https://codecov.io/gh/Dmitry8ms/job4j_design/branch/master/graph/badge.svg?token=6SCYJGSTA8)](https://codecov.io/gh/Dmitry8ms/job4j_design)